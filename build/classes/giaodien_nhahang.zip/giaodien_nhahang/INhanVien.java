package giaodien_nhahang;

public interface INhanVien {
     double TinhLuong();
}
