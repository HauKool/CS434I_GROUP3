
package giaodien_nhahang;

public class NV_tren18t extends NhanVien {
    
    public NV_tren18t(String HoTen, String ChucVu, String GioiTinh, int NamSinh, double SoNgayLam, double Luong, String Sdt) {
        super(HoTen, ChucVu, GioiTinh, NamSinh, SoNgayLam, Luong, Sdt);
    }

  
    
    
}
